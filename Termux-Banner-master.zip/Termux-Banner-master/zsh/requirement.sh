
#!/bin/bash

clear
apt update
apt upgrade
apt install figlet -y
figlet Basic Installation
apt install toilet -y
apt install cowsay -y
apt install nano -y
apt install ruby -y
gem install lolcat
figlet -f big Done !!! | lolcat
echo
echo -e "\e[1m Now Run \e[32mbash t-ban.sh\e[0m...!!!"
echo
echo -e "\e[1m\e[32m Developed by :\e[33m Sutariya Parixit (8h4i)"
echo
echo
